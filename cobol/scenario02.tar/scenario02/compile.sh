#!/bin/sh

source=$1

cobc ${source}
