#!/bin/sh

exec_BATCH001.sh &
sleep 30
exec_BATCH002.sh &
sleep 30
exec_BATCH003.sh &
sleep 30
exec_BATCH004.sh &
sleep 30
exec_BATCH005.sh &

